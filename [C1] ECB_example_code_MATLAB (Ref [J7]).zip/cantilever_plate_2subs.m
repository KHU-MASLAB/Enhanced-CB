%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%      Enhanced CB example code
%      May 25, 2018
%
%      Jin-Gyun Kim, Ph.D, Assistant professor
%      Modeling and Simulation (M&S) lab
%      Department of Mechanical Engineering, Kyung Hee University
%      jingyun.kim@khu.ac.kr, jingyun.kim@gmail.com
%
%      Cantilever plate problem
%      Modal analysis, transient analysis
%
%      References:
%
%      JG Kim, PS Lee, An enhanced Craig-Bampton method, International 
%      Journal for Numerical Methods in Engineering, 103, 79-93, 2015
%   
%      JG Kim, YJ Park, GH Lee, DN Kim, A general model reduction with 
%      primal assembly in structural dynamics, Computer Methods in Applied 
%      Mechanics and Engineering, 324, 1-28, September 2017.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
clc

% Original system ---------------------------------------------------------
MM = load('cbexample_Mt.txt');
KK = load('cbexample_Kt.txt'); 
size_free = length(MM);
node_dof = 3; 
K = KK(22:size_free,22:size_free);
M = MM(22:size_free,22:size_free);
sdof = length(K);

% Point load
P1 = zeros(sdof - 7*node_dof);
P = [diag(P1);0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;-1;0;0];
 
% Substructuring
K22_1 = K([1:168],[1:168]); 
K22_2 = K([190:252],[190:252]); 
K21_1 = K([1:168],[169:189]); 
K21_2 = K([190:252],[169:189]); 
K22 = blkdiag(K22_1, K22_2);
K21 = [K21_1; K21_2];

M22_1 = M([1:168],[1:168]); 
M22_2 = M([190:252],[190:252]); 
M21_1 = M([1:168],[169:189]); 
M21_2 = M([190:252],[169:189]); 
M22 = blkdiag(M22_1, M22_2);
M21 = [M21_1; M21_2];

K11 = K([169:189],[169:189]);
M11 = M([169:189],[169:189]);
K12 = K21';
M12 = M21';

P22_1 = P([1:168]);
P22_2 = P([190:252]);
P22 = [P22_1; P22_2];

C22_1 = zeros(size(K22_1));
C22_2 = zeros(size(K22_2));
C22 = zeros(size(K22));

K = [K22, K21; K12, K11];
M = [M22, M21; M12, M11]; 

% damping effects
C = zeros(sdof);

% Transforming the System Matrices to modal coordinates
lambda = sdof;  % Number of modes to be considered
[Mn,Kn,Cn,Pn,phin]= ModalAnalysis(M,K,C,P,lambda);

% Newmark Method for time integration
acceleration = 'Average';
% acceleration = 'Linear';
[depl,vel,accl,U,t] = NewmarkMethod(Mn,Kn,Cn,Pn,phin,sdof,acceleration);
 
% CB system ---------------------------------------------------------------
nmode1 = 5;  % Number of retained modes in subs1
nmode2 = 3;  % Number of retained modes in subs2
nmode = nmode1 + nmode2;

[Ms1,Ks1,Cs1,Ps1,phis1]= ModalAnalysis(M22_1,K22_1,C22_1,P22_1,nmode1);
[Ms2,Ks2,Cs2,Ps2,phis2]= ModalAnalysis(M22_2,K22_2,C22_2,P22_2,nmode2);

phis = blkdiag(phis1, phis2);
Ks = blkdiag(Ks1, Ks2);

inv_K22 = inv(K22);
Psi = -inv_K22*K21;
T_cb = [phis Psi; zeros(size(K12,1), size(phis, 2)) eye(size(K11))];
M_cb = T_cb'*M*T_cb;
K_cb = T_cb'*K*T_cb;
C_cb = T_cb'*C*T_cb;
P_cb = T_cb'*P;

% Transforming the System Matrices to modal coordinates
lambda_r0 = length(K_cb);  % Number of modes to be considered
[M_r0,K_r0,C_r0,P_r0,phi_r0]= ModalAnalysis(M_cb,K_cb,C_cb,P_cb,lambda_r0);

% Newmark Method for time integration
[depl_r0,vel_r0,accl_r0,U_r0,t] = NewmarkMethod(M_r0,K_r0,C_r0,P_r0,phi_r0,lambda_r0,acceleration);

% Enhanced CB system ------------------------------------------------------
F_rs = inv_K22 - phis*inv(Ks)*phis';
t_r = F_rs*(M22*Psi + M21);
T_r = [zeros(size(phis,1), size(phis,2)) t_r; zeros(size(K12,1), size(phis, 2)) zeros(size(K11,1), size(K11, 2))]*inv(M_cb)*K_cb;
T_ecb = T_cb + T_r;
M_ecb = T_ecb'*M*T_ecb;
K_ecb = T_ecb'*K*T_ecb;
C_ecb = T_ecb'*C*T_ecb;
P_ecb = T_ecb'*P;

% Transforming the System Matrices to modal coordinates
[M_r1,K_r1,C_r1,P_r1,phi_r1]= ModalAnalysis(M_ecb,K_ecb,C_ecb,P_ecb,lambda_r0);

% Newmark Method for time integration
[depl_r1,vel_r1,accl_r1,U_r1,t] = NewmarkMethod(M_r1,K_r1,C_r1,P_r1,phi_r1,lambda_r0,acceleration);

% relative eigenvalue error ----------------------------------------------
ref_eig = diag(Kn);
cb_eig = diag(K_r0);
ecb_eig = diag(K_r1);

nf = size(cb_eig);
 for i = 1 : nf;
    cb_eig_error(i) = [ abs( ref_eig(i) - cb_eig(i) ) ]./ref_eig(i);
    ecb_eig_error(i) = [ abs( ref_eig(i) - ecb_eig(i) ) ]./ref_eig(i);
 end
 
figure()
semilogy(1:nf,cb_eig_error(1:nf), '-b' )
hold on
semilogy(1:nf,ecb_eig_error(1:nf), '-r' )
hold on
xlabel('Mode number')
ylabel('Relative eigenvalue error')
legend('CB', 'ECB')
grid

% displacement of master DOFs  ------------------------------------------------------
figure()
plot(t,U(sdof-node_dof+1,:), '-k')
hold on
plot(t,U_r0(lambda_r0-node_dof+1,:), '-b')
hold on
plot(t,U_r1(lambda_r0-node_dof+1,:), '-r')
hold on
xlabel('Time (s)') 
ylabel('Deflection (w_z)')
legend('Ref.', 'CB', 'ECB')
grid


