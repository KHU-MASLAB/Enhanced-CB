function [M,K,C,P,phi]= ModalAnalysis(M,K,C,P,lambda)
% Modal Analysis of the System 
%--------------------------------------------------------------------------
% Purpose : To do the Modal Analysis of the system
%
% Synopsis : [M,K,C,P] = ModalAnalysis(M,K,C,P,lambda)
%
% Variable Description :
%           M - Mass Matrix
%           K - Stiffness Matrix
%           C - Damping Matrix
%           P - Force MAtrix
%           lambda - number of modes to be considered
%           phi - Reduced Normal modes of the system
%--------------------------------------------------------------------------

% Modal Analysis 
[V,D]=eig(K,M);
[W,k]=sort(diag(D));
V=V(:,k); 
Factor=diag(V'*M*V);
Phi=V*inv(sqrt(diag(Factor)));

% selecting only first two Natural Frequencies and Mode shapes
phi = Phi(:,1:lambda) ;

% Reducing the Degree's of Freedom of M, K and P
M = eye(lambda);
K = diag(W(1:lambda));
C = phi'*C*phi ;
P = phi'*P ;